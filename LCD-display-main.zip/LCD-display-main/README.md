# LCD-display
This project demonstrates how to interface a 16x2 LCD display with a microcontroller using Embedded C. The program initializes the LCD and displays text or messages on the screen, providing a basic understanding of LCD communication and display control.
